Author: Taylor Thomas


Genealogy.cpp is a program that takes two main commands:
 1) family n husband n wife n child n child n ......
 Capitalization does not matter.
 Where n represents the number of a unique person who is a 
 husband, wife, or child, as specified by the prior token. 
 OR
 n represents the number of a unique family, which contains the
 following family members.
 
 2) relate n n
 Capitalization does not matter.
 Where n are two persons.
 Returns the shortest path from n (1) to n(2) using the connected
 vertices made with the family command.
 
Files:

- Genealogy.cpp
	- Main driver program containing necessary code to take commands from stdin and properly 
	calculate and print desired output.	
- Makefile
	- Makefile provided by Dr. Finkel to compile genealogy.cpp and pipe in data.txt.	
- data.txt
	- Sample data provided by Dr. Finkel.
- myData.txt
	- My sample data to run through program.
- tmpRunOut.out
	- output from data.txt.
- myOutputData.txt
	- output from myData.txt.
